package AirFreightApp;
/*
 * Group Members:

 * 1. Student Name: Wasan Almutaani | ID: 2115109 | Email: walmutaani@stu.kau.edu.sa

 * 2. Student Name: Anhar Batook |  ID: 2006562 | Email: aahmedbatook@stu.kau.edu.sa

 * 3. Student Name: Reem Bahassan |  ID: 2208721 |
 */
import GraphFramework.*;
import java.io.*;

public class AFRouteMap extends Graph {
    public AFRouteMap() {
        super();
        isDigraph = true;
    }

    @Override
    public Vertex createVertex(String label, int weight) {
        return new Location(label, "city "+weight);
    }

    @Override
    public Edge createEdge(Vertex v, Vertex u, int weight) {
        return new Route(v, u, weight);
    }

    public static void main(String[] args) {
        AFRouteMap map1= new AFRouteMap();AFRouteMap map2= new AFRouteMap();AFRouteMap map3 = new AFRouteMap();
        try {
            map1.readGraphFromFile("graph.txt");
            map2.readGraphFromFile("graph1.txt");
            map3.readGraphFromFile("graph3.txt");
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        }
        
        System.out.println("First file output:");
        DBAllSourceSPAlg alg = new DBAllSourceSPAlg(map1);
        alg.computeDijkstraBasedSPAlg();
            
        System.out.println("Second file output:");
        DBAllSourceSPAlg alg1 = new DBAllSourceSPAlg(map2);
            alg1.computeDijkstraBasedSPAlg();
        System.out.println("Third file output:");
        DBAllSourceSPAlg alg3 = new DBAllSourceSPAlg(map3);
            alg3.computeDijkstraBasedSPAlg();    
    }
}
