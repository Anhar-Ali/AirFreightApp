package AirFreightApp;
import GraphFramework.*;

public class Location extends Vertex {
	// Name of the city associated with this location
    private String city;

    public Location(String label, String city) {
        super(label);
        this.city = city;
    }

    @Override
    public void displayInfo() {
        System.out.print("loc. "+label+": "+city);
    }

    public void displayInfo(String cityName) {
        this.city = cityName;
    }

    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city=city;
    }
}