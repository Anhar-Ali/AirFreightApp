package AirFreightApp;

import GraphFramework.*;

public class Route extends Edge {
    public Route(Vertex parent, Vertex target, int weight) {
        super(parent, target, weight);
    }

    @Override
    public void displayInfo() {
        System.out.print("Route from " + parent.getLabel() + " to " + target.getLabel() + ", distance: " + weight);
    }
}
