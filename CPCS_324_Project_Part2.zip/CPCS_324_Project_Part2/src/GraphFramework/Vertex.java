package GraphFramework;
import java.util.ArrayList;
import java.util.List;


public class Vertex {
	
    // Unique label identifying the vertex
    protected String label;
    // Flag indicating whether the vertex has been visited
    protected boolean isVisited;
    // List of edges originating from this vertex
    protected List<Edge> adjList;


    public Vertex(String label) {
        this.label = label;
        this.isVisited = false;
        this.adjList = new ArrayList<>();
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public boolean isVisited() {
        return isVisited;
    }

    public void setVisited(boolean visited) {
        this.isVisited = visited;
    }

    public List<Edge> getAdjList() {
        return adjList;
    }

    public void displayInfo() {
        System.out.print("Vertex: " + label);
    }
}
