package GraphFramework;
import java.util.*;

public class DBAllSourceSPAlg extends ShortestPathAlgorithm {
    // Store shortest paths as lists of edges ,and distances.
    private Map<Vertex, Map<Vertex, List<Edge>>> shortestPaths;
    private Map<Vertex, Map<Vertex, Integer>> distances;

    public DBAllSourceSPAlg(Graph graph) {
        super(graph);
        shortestPaths = new HashMap<>();
        distances = new HashMap<>();
    }

    public void computeDijkstraBasedSPAlg() {
        SingleSourceSPAlg singleSourceAlg = new SingleSourceSPAlg(graph);
        for (Vertex source : graph.vertices) {
            Map<Vertex, Vertex> predecessors = new HashMap<>();
            Map<Vertex, Integer> sourceDistances = singleSourceAlg.computeDijkstraAlg(source, predecessors);

            // Initialize shortest paths for this source
            Map<Vertex, List<Edge>> pathsFromSource = new HashMap<>();
            distances.put(source, sourceDistances);

            // Reconstruct paths and store as lists of edges
            for (Vertex target : graph.vertices) {
                if (target.equals(source)) continue;
                List<Edge> edgePath = getEdgePath(predecessors, source, target);
                pathsFromSource.put(target, edgePath);
            }
            shortestPaths.put(source, pathsFromSource);
        }

        // Print results in the specified format
        printShortestPaths();
    }

    private List<Edge> getEdgePath(Map<Vertex, Vertex> predecessors, Vertex source, Vertex target) {
        // First, reconstruct the vertex path
        List<Vertex> vertexPath = new ArrayList<>();
        Vertex current = target;
        while (current != null) {
            vertexPath.add(current);
            current = predecessors.get(current);
        }
        Collections.reverse(vertexPath);

        // Convert vertex path to edge path
        List<Edge> edgePath = new ArrayList<>();
        if (vertexPath.size() <= 1 || vertexPath.get(0) != source) {
            return edgePath; // Empty path if target is unreachable
        }

        for (int i = 0; i < vertexPath.size() - 1; i++) {
            Vertex u = vertexPath.get(i);
            Vertex v = vertexPath.get(i + 1);
            // Find the edge from u to v
            for (Edge edge : u.getAdjList()) {
                if (edge.getTarget().equals(v)) {
                    edgePath.add(edge);
                    break;
                }
            }
        }
        return edgePath;
    }

    private void printShortestPaths() {
        for (Vertex source : graph.vertices) {
            System.out.println("The starting point location is " + source.getLabel());
            System.out.println("The routes from location " + source.getLabel() + " to the rest of the locations are:");
            Map<Vertex, List<Edge>> pathsFromSource = shortestPaths.get(source);
            Map<Vertex, Integer> sourceDistances = distances.get(source);

            for (Vertex target : graph.vertices) {
                if (target.equals(source)) continue;
                List<Edge> edgePath = pathsFromSource.get(target);
                StringBuilder pathStr = new StringBuilder();

                // If path is empty, target is unreachable
                if (edgePath.isEmpty()) {
                    target.displayInfo();
                    pathStr.append(" --- route length: unreachable");
                } else {
                    // Build path string using vertices
                    List<Vertex> vertexPath = new ArrayList<>();
                    vertexPath.add(source);
                    source.displayInfo();
                    for (Edge edge : edgePath) {
                    	System.out.print(" – ");
                    	Vertex v = edge.getTarget();
                        vertexPath.add(v);
                        v.displayInfo();
                    }
                    pathStr.append(" --- route length: ").append(sourceDistances.get(target));
                }
                System.out.println(pathStr);
            }
            System.out.println();
        }
    }
} 