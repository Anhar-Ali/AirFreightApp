package GraphFramework;

import java.util.*;


public class SingleSourceSPAlg extends ShortestPathAlgorithm {
    public SingleSourceSPAlg(Graph graph) {
        super(graph);
    }

    //Computes the shortest paths from a source vertex to all other vertices using Dijkstra's algorithm.
    public Map<Vertex, Integer> computeDijkstraAlg(Vertex source, Map<Vertex, Vertex> predecessors) {
        
    	// Initialize distances and priority queue
        Map<Vertex, Integer> distances = new HashMap<>();
        PriorityQueue<Map.Entry<Vertex, Integer>> Q = new PriorityQueue<>(
                Comparator.comparingInt(Map.Entry::getValue));
        Set<Vertex> V_T = new HashSet<>();

        // Step 1: Initialize distances and predecessors
        for (Vertex v : graph.vertices) {
            distances.put(v, Integer.MAX_VALUE);
            predecessors.put(v, null);
            Q.offer(new AbstractMap.SimpleEntry<>(v, distances.get(v)));
        }

        // Step 2: Set source distance to 0 and update priority queue
        distances.put(source, 0);
        Q.removeIf(entry -> entry.getKey().equals(source));
        Q.offer(new AbstractMap.SimpleEntry<>(source, 0));

        // Step 3: Main loop for Dijkstra's algorithm
        for (int i = 0; i < graph.vertices.size(); i++) {
            // Step 4: Extract vertex with minimum distance
            Map.Entry<Vertex, Integer> minEntry = null;
            while (!Q.isEmpty()) {
                minEntry = Q.poll();
                if (!V_T.contains(minEntry.getKey())) {
                    break;
                }
            }
            if (minEntry == null) break; // No reachable vertices left

            Vertex uStar = minEntry.getKey();
            V_T.add(uStar);

            // Step 5: For each adjacent vertex not in V_T
            for (Edge edge : uStar.getAdjList()) {
                Vertex u = edge.getTarget();
                if (V_T.contains(u)) continue;

                int d_uStar = distances.get(uStar);
                int w = edge.getWeight();
                int d_u = distances.get(u);

                // Step 6: Relax the edge
                if (d_uStar != Integer.MAX_VALUE && d_uStar + w < d_u) {
                    distances.put(u, d_uStar + w);
                    predecessors.put(u, uStar);
                    // Update priority queue
                    Q.removeIf(entry -> entry.getKey().equals(u));
                    Q.offer(new AbstractMap.SimpleEntry<>(u, distances.get(u)));
                }
            }
        }

        return distances;
    }}
