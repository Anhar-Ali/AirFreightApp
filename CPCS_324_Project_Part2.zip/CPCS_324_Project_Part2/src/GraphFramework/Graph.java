package GraphFramework;

import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import AirFreightApp.*;

public abstract class Graph {
	
    // Number of vertices in the graph
    protected int verticesNo;
    // Number of edges in the graph
    protected int edgeNo;
    // Flag indicating if the graph is directed
    protected boolean isDigraph;
    // List of vertices in the graph
    protected List<Vertex> vertices;

    public Graph() {
        vertices = new ArrayList<>();
        verticesNo = 0;
        edgeNo = 0;
        isDigraph = false;
    }

    //Must be implemented by subclasses.
    public abstract Vertex createVertex(String label, int weight/*used to name city in Location*/);

    //Must be implemented by subclasses.
    public abstract Edge createEdge(Vertex v, Vertex u, int weight);

    // Adds an edge to the graph between two vertices.
    public void addEdge(String vLabel, String uLabel, int weight) {
        Vertex v = null, u = null;
        for (Vertex vertex : vertices) {
            if (vertex.getLabel().equals(vLabel)) v = vertex;
            if (vertex.getLabel().equals(uLabel)) { 
            	u = vertex;
            	// Set city name for target vertex based on edge weight
            	((Location)u).setCity("city "+ weight);}
        }
        if (v == null) {
            v = createVertex(vLabel,weight);
            vertices.add(v);
            verticesNo++;
        }
        if (u == null) {
            u = createVertex(uLabel,1);
            vertices.add(u);
            verticesNo++;
        }
        Edge edge = createEdge(v, u, weight);
        v.getAdjList().add(edge);
        edgeNo++;
    }

    public void readGraphFromFile(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        Scanner scanner = new Scanner(file);
        
        // Read digraph indicator 
        scanner.next();
        isDigraph = scanner.nextInt()==0; // Directed graph as per project
        
        // Read number of vertices and edges
        verticesNo =scanner.nextInt();
        edgeNo = scanner.nextInt();
        
        // Read edges
        while (scanner.hasNextLine()) {
            if (!scanner.hasNext(Pattern.compile("..[0-9]"))) {
            	scanner.nextLine();
			}
            String vLabel = scanner.next();
            String uLabel = scanner.next();
            int weight = scanner.nextInt();
            addEdge(vLabel, uLabel, weight);
        }
        scanner.close();
    }
}