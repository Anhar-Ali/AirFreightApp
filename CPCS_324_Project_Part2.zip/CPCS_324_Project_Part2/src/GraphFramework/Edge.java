package GraphFramework;


public abstract class Edge {
	
    // Source vertex of the edge
    protected Vertex parent;
    // Destination vertex of the edge
    protected Vertex target;
    // Weight of the edge
    protected int weight;

    public Edge(Vertex parent, Vertex target, int weight) {
        this.parent = parent;
        this.target = target;
        this.weight = weight;
    }

    public Vertex getParent() {
        return parent;
    }

    public Vertex getTarget() {
        return target;
    }

    public int getWeight() {
        return weight;
    }

    public void displayInfo() {
        System.out.print("Edge: " + parent.getLabel() + " to " + target.getLabel() + ", weight: " + weight);
    }
}