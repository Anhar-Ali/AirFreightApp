package GraphFramework;


public abstract class ShortestPathAlgorithm {
    protected Graph graph;

    public ShortestPathAlgorithm(Graph graph) {
        this.graph = graph;
    }
}